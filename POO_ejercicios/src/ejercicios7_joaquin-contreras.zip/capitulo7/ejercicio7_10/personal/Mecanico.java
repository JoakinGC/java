package capitulo7.ejercicio7_10.personal;

public class Mecanico {
	// Lo mismo que la clase maquinista.
	String nombre; 
	String telefono; 
	String especialidad;
	
	public Mecanico(String nombre, String telefono, String especialidad) { 
		this.nombre = nombre; 
		this.telefono = telefono; 
		this.especialidad = especialidad;
	}
}
