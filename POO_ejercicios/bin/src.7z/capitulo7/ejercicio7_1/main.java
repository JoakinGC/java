package capitulo7.ejercicio7_1;

public class main {

	public static void main(String[] args) {
		/**/
		
		
		
		

	}

}
