package capitulo7.ejercicio7_10;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
