package generales.ejercicio7Y8;

public class Vehiculo {

}
