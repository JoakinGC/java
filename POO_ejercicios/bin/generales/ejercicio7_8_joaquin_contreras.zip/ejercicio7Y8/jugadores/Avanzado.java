package generales.ejercicio7Y8.jugadores;

public class Avanzado extends Jugador{
	private final int ataque = -5;
	private int muertes;
	
	public Avanzado() {
		super();
	}
	
	public int getAtaque() {
		return ataque;
	}
	
	public int getMuertes() {
		return muertes;
	}

	public void setMuertes(int muertes) {
		
		if(vida == 0) {
			
		}
		
	}
}
