package generales.ejercicio7Y8.jugadores;

public class Principiante  extends Jugador{
	
	private final int ataque = -3;
	private int muertes;
	
	public Principiante() {
		super();	
	}

	public int getAtaque() {
		return ataque;
	}

	public int getMuertes() {
		return muertes;
	}

	public void setMuertes(int muertes) {
		
		if(vida == 0) {
			
		}
		
	}


}
