package generales;

import generales.ejercicio7Y8.Game;

public class Main {

	public static void main(String[] args) {
		Game juego = new Game();

	}

}
