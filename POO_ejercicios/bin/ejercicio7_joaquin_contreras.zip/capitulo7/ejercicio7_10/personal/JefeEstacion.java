package capitulo7.ejercicio7_10.personal;

public class JefeEstacion {
	String nombre; 
	String dni;
	
	public JefeEstacion(String nombre, String dni) { 
		this.nombre = nombre; 
		this.dni = dni; 
	}
}
