package capitulo7.ejercicio7_10.personal;

public class Mecanico {

}
