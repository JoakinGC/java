package capitulo7.ejercicio7_10;

public class vagon {
	
	int capacidadMax; 
	int capacidadActual; 
	String mercancia; 
	
	 
	 
	public vagon(int capacidadMax, int capacidadActual, String mercancia) { 
		this.capacidadMax = capacidadMax; 
		this.capacidadActual = capacidadActual; 
		this.mercancia = mercancia;
	}
}
